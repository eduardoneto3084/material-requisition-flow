import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { dirname } from "path";
import { 
  insertRequisitionSchema, 
  insertUserSchema, 
  insertProjectSchema,
  updateRequisitionStatusSchema,
  RequisitionStatus,
  UserRole,
  UserPermissions
} from "@shared/schema";
import { z } from "zod";
import { 
  sendOperationalApprovalEmail, 
  sendWarehouseApprovalEmail,
  sendDirectorApprovalEmail
} from "./emailService";
import { setupAuth } from "./auth";

// Define __dirname equivalent for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Configurar o multer para armazenamento de arquivos
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const uploadDir = path.join(__dirname, "uploads");
      
      // Criar diretório se não existir
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }
      
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, uniqueSuffix + path.extname(file.originalname));
    }
  }),
  fileFilter: (req, file, cb) => {
    // Aceitar apenas arquivos PDF
    if (file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Apenas arquivos PDF são aceitos'));
    }
  },
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB
  }
});

// Funções auxiliares
function validateBody<T>(schema: z.ZodType<T>) {
  return (req: Request, res: Response, next: () => void) => {
    try {
      req.body = schema.parse(req.body);
      next();
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          message: "Invalid data", 
          errors: error.errors 
        });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  };
}

// Authentication middleware
function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}

// Permission middleware generators
function hasPermission(permission: keyof UserPermissions) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const user = req.user as Express.User;
    if (user.permissions[permission]) {
      return next();
    }
    
    res.status(403).json({ message: "Forbidden: Insufficient permissions" });
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Set up authentication
  setupAuth(app);
  
  // Serve PDF files
  app.use('/api/uploads', express.static(path.join(__dirname, 'uploads')));
  
  // Information endpoint for seeding users
  app.get('/api/seed-users', async (req, res) => {
    res.json({ 
      message: "Make a POST request to /api/seed-users to seed initial users with default credentials." 
    });
  });
  
  // User routes
  app.get('/api/users', isAuthenticated, async (req, res) => {
    try {
      const users = await storage.getUsers();
      res.json(users.map(user => ({
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email,
        role: user.role
      })));
    } catch (error) {
      res.status(500).json({ message: "Error retrieving users" });
    }
  });
  
  app.get('/api/users/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email,
        role: user.role
      });
    } catch (error) {
      res.status(500).json({ message: "Error retrieving user" });
    }
  });
  
  // Project routes
  app.get('/api/projects', isAuthenticated, async (req, res) => {
    try {
      const projects = await storage.getProjects();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving projects" });
    }
  });
  
  // Requisition routes
  app.post('/api/requisitions', 
    hasPermission('canCreateRequisition'), 
    upload.single('pdf'), 
    async (req, res) => {
      try {
        if (!req.file) {
          return res.status(400).json({ message: "PDF file is required" });
        }
        
        const user = req.user as Express.User;
        
        const requisitionData = {
          ...req.body,
          requesterId: user.id,
          pdfPath: req.file.path,
          pdfName: req.file.originalname,
          pdfSize: req.file.size,
          projectId: req.body.projectId,
        };
        
        // Validate the data
        const validatedData = insertRequisitionSchema.parse(requisitionData);
        
        // Create the requisition
        const requisition = await storage.createRequisition(validatedData);
        
        // Send initial notification to operational manager
        await sendOperationalApprovalEmail(requisition);
        
        res.status(201).json(requisition);
      } catch (error) {
        if (error instanceof z.ZodError) {
          res.status(400).json({ 
            message: "Invalid data", 
            errors: error.errors 
          });
        } else {
          console.error(error);
          res.status(500).json({ message: "Error creating requisition" });
        }
      }
    }
  );
  
  app.get('/api/requisitions', isAuthenticated, async (req, res) => {
    try {
      const user = req.user as Express.User;
      let requisitions;
      
      // Filter by status if provided
      if (req.query.status) {
        requisitions = await storage.getRequisitionsByStatus(req.query.status as RequisitionStatus);
      } 
      // Filter by requester if "mine" is true
      else if (req.query.mine === 'true') {
        if (user.permissions.canViewMyRequisitions) {
          requisitions = await storage.getRequisitionsByRequesterId(user.id);
        } else {
          return res.status(403).json({ message: "Forbidden: Insufficient permissions" });
        }
      } 
      // Otherwise, return all
      else {
        requisitions = await storage.getRequisitions();
      }
      
      res.json(requisitions);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving requisitions" });
    }
  });
  
  app.get('/api/requisitions/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const requisition = await storage.getRequisition(id);
      
      if (!requisition) {
        return res.status(404).json({ message: "Requisition not found" });
      }
      
      const user = req.user as Express.User;
      
      // Check if user has permission to view this requisition
      if (requisition.requesterId !== user.id && 
          !user.permissions.canApproveOperational && 
          !user.permissions.canApproveWarehouse && 
          !user.permissions.canApproveDirector && 
          !user.permissions.canPrepareMaterials && 
          !user.permissions.canShipMaterials) {
        return res.status(403).json({ message: "Forbidden: Insufficient permissions" });
      }
      
      res.json(requisition);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving requisition" });
    }
  });
  
  // Update requisition status - different checks based on the current status
  app.patch('/api/requisitions/:id/status', 
    isAuthenticated,
    validateBody(updateRequisitionStatusSchema),
    async (req, res) => {
      try {
        const id = parseInt(req.params.id);
        const user = req.user as Express.User;
        const update = req.body;
        
        // Get the requisition before update to check previous status
        const requisitionBefore = await storage.getRequisition(id);
        if (!requisitionBefore) {
          return res.status(404).json({ message: "Requisition not found" });
        }
        
        // Check permissions based on the current requisition status
        if (requisitionBefore.status === RequisitionStatus.PENDING_OPERATIONAL && 
            !user.permissions.canApproveOperational) {
          return res.status(403).json({ message: "Forbidden: No permission to approve operational" });
        }
        
        if (requisitionBefore.status === RequisitionStatus.PENDING_WAREHOUSE && 
            !user.permissions.canApproveWarehouse) {
          return res.status(403).json({ message: "Forbidden: No permission to approve warehouse" });
        }
        
        if (requisitionBefore.status === RequisitionStatus.PENDING_DIRECTOR && 
            !user.permissions.canApproveDirector) {
          return res.status(403).json({ message: "Forbidden: No permission to approve director" });
        }
        
        if (requisitionBefore.status === RequisitionStatus.APPROVED && 
            update.status === RequisitionStatus.IN_PREPARATION && 
            !user.permissions.canPrepareMaterials) {
          return res.status(403).json({ message: "Forbidden: No permission to prepare materials" });
        }
        
        if (requisitionBefore.status === RequisitionStatus.IN_PREPARATION && 
            update.status === RequisitionStatus.SHIPPED && 
            !user.permissions.canShipMaterials) {
          return res.status(403).json({ message: "Forbidden: No permission to ship materials" });
        }

        // Update the requisition status
        const requisition = await storage.updateRequisitionStatus(id, user.id, update);
        
        // Send email notifications based on the new status
        if (update.status === RequisitionStatus.PENDING_WAREHOUSE && 
                  requisitionBefore.status === RequisitionStatus.PENDING_OPERATIONAL) {
          // If operational manager approved, send email to warehouse manager
          await sendWarehouseApprovalEmail(requisition);
        } else if (update.status === RequisitionStatus.PENDING_DIRECTOR && 
                  requisitionBefore.status === RequisitionStatus.PENDING_WAREHOUSE) {
          // If warehouse manager approved, send email to director
          await sendDirectorApprovalEmail(requisition);
        }
        
        res.json(requisition);
      } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Error updating requisition status" });
      }
    }
  );

  return httpServer;
}

import express from "express";

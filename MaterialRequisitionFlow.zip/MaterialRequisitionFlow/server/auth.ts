import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { UserRole, UserPermissions } from "@shared/schema";

// Add User type to Express namespace
declare global {
  namespace Express {
    interface User {
      id: number;
      username: string;
      name: string;
      email: string;
      role: string;
      permissions: UserPermissions;
    }
  }
}

const scryptAsync = promisify(scrypt);

// Custom function to create permissions based on email
function createCustomPermissions(email: string): UserPermissions {
  // Default permissions - everyone can create requisitions and view their own
  const permissions: UserPermissions = {
    canCreateRequisition: true,
    canViewMyRequisitions: true,
    canApproveOperational: false,
    canApproveWarehouse: false,
    canApproveDirector: false,
    canPrepareMaterials: false,
    canShipMaterials: false,
    canViewHistory: false,
    canViewDashboard: true,
  };

  // Eduardo Neto - Has all permissions
  if (email === "eduardo.neto@aerisservice.com") {
    permissions.canApproveOperational = true;
    permissions.canApproveWarehouse = true;
    permissions.canPrepareMaterials = true;
    permissions.canShipMaterials = true;
    permissions.canViewHistory = true;
  }
  // Trevor, Nestor, Matheus - Warehouse team, but no approvals
  else if (["trevor.krahn@aerisservice.com", "nestor.reyes@aerisservice.com", "matheus.cruz@aerisenergy.com.br"].includes(email)) {
    permissions.canPrepareMaterials = true;
    permissions.canShipMaterials = true;
    permissions.canViewHistory = true;
  }
  // Saul, Jordy, Victor, Jesus - Field team with minimal permissions
  else if (["saul.ramirez@aerisservice.com", "jordy.perez@aerisservice.com", "victor.vidal@aerisservice.com", "jesus.garcia@aerisservice.com"].includes(email)) {
    // Default permissions only
  }
  // Ricardo and Evandro - can approve
  else if (email === "ricardo.arellano@aerisservice.com") {
    permissions.canApproveOperational = true;
    permissions.canViewHistory = true;
  }
  else if (email === "evandro.prado@aerisservice.com") {
    permissions.canApproveDirector = true;
    permissions.canViewHistory = true;
  }
  // All other operational managers - no special permissions beyond default
  
  return permissions;
}

function createPermissionsForRole(role: UserRole): UserPermissions {
  const defaultPermissions: UserPermissions = {
    canCreateRequisition: true,
    canViewMyRequisitions: true,
    canApproveOperational: false,
    canApproveWarehouse: false,
    canApproveDirector: false,
    canPrepareMaterials: false,
    canShipMaterials: false,
    canViewHistory: false,
    canViewDashboard: true,
  };

  switch (role) {
    case UserRole.ADMIN:
      return {
        canCreateRequisition: true,
        canViewMyRequisitions: true,
        canApproveOperational: true,
        canApproveWarehouse: true,
        canApproveDirector: true,
        canPrepareMaterials: true,
        canShipMaterials: true,
        canViewHistory: true,
        canViewDashboard: true,
      };
    case UserRole.OPERATIONAL:
      return {
        ...defaultPermissions,
        canApproveOperational: true,
        canViewHistory: true,
      };
    case UserRole.WAREHOUSE:
      return {
        ...defaultPermissions,
        canApproveWarehouse: true,
        canPrepareMaterials: true,
        canShipMaterials: true,
        canViewHistory: true,
      };
    case UserRole.DIRECTOR:
      return {
        ...defaultPermissions,
        canApproveDirector: true,
        canViewHistory: true,
      };
    case UserRole.FIELD:
      return defaultPermissions;
    default:
      return defaultPermissions;
  }
}

async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const derivedKey = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${derivedKey.toString("hex")}.${salt}`;
}

async function comparePasswords(plaintext: string, hash: string): Promise<boolean> {
  const [hashedPassword, salt] = hash.split(".");
  const hashedBuffer = Buffer.from(hashedPassword, "hex");
  const derivedKey = (await scryptAsync(plaintext, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuffer, derivedKey);
}

export function setupAuth(app: Express) {
  const sessionSecret = process.env.SESSION_SECRET || randomBytes(32).toString("hex");
  
  // Session configuration
  app.use(
    session({
      secret: sessionSecret,
      resave: false,
      saveUninitialized: false,
      store: storage.sessionStore,
      cookie: {
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
      },
    })
  );

  // Initialize Passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Configure Local Strategy
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        
        if (!user) {
          return done(null, false, { message: "Invalid username or password" });
        }
        
        const isPasswordValid = await comparePasswords(password, user.password);
        
        if (!isPasswordValid) {
          return done(null, false, { message: "Invalid username or password" });
        }
        
        return done(null, user);
      } catch (error) {
        return done(error);
      }
    })
  );

  // Serialize and deserialize user
  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      if (!user) {
        return done(null, false);
      }
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Register endpoint
  app.post("/api/register", async (req, res) => {
    try {
      // In our system, email is used as the username
      const { password, name, email, role = UserRole.FIELD } = req.body;
      const username = email; // Use email as username
      
      // Check if email already exists as a username
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Email already registered" });
      }
      
      const hashedPassword = await hashPassword(password);
      // Use our custom permissions function that uses email to determine permissions
      const permissions = createCustomPermissions(email);
      
      const user = await storage.createUser({
        username,
        password: hashedPassword,
        name,
        email,
        role,
        permissions,
      });
      
      // Log the user in automatically after registration
      req.login(user, (err: any) => {
        if (err) {
          return res.status(500).json({ message: "Error during login after registration" });
        }
        
        return res.status(201).json({
          id: user.id,
          username: user.username,
          name: user.name,
          email: user.email,
          role: user.role,
          permissions: user.permissions,
        });
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Error during registration" });
    }
  });

  // Login endpoint
  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err: any, user: any, info: { message?: string }) => {
      if (err) {
        return next(err);
      }
      
      if (!user) {
        return res.status(401).json({ message: info?.message || "Authentication failed" });
      }
      
      req.login(user, (err: any) => {
        if (err) {
          return next(err);
        }
        
        return res.json({
          id: user.id,
          username: user.username,
          name: user.name,
          email: user.email,
          role: user.role,
          permissions: user.permissions,
        });
      });
    })(req, res, next);
  });

  // Logout endpoint
  app.post("/api/logout", (req, res) => {
    req.logout((err: any) => {
      if (err) {
        return res.status(500).json({ message: "Error during logout" });
      }
      res.json({ message: "Successfully logged out" });
    });
  });

  // Get current user
  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const user = req.user as Express.User;
    res.json({
      id: user.id,
      username: user.username,
      name: user.name,
      email: user.email,
      role: user.role,
      permissions: user.permissions,
    });
  });

  // Seed initial users for testing/demo
  app.post("/api/seed-users", async (req, res) => {
    try {
      const userProfiles = [
        // Warehouse team
        {
          name: "Eduardo Neto",
          email: "eduardo.neto@aerisservice.com",
          role: UserRole.WAREHOUSE,
        },
        {
          name: "Trevor Krahn",
          email: "trevor.krahn@aerisservice.com",
          role: UserRole.WAREHOUSE,
        },
        {
          name: "Nestor Reyes",
          email: "nestor.reyes@aerisservice.com",
          role: UserRole.WAREHOUSE,
        },
        {
          name: "Matheus Cruz",
          email: "matheus.cruz@aerisenergy.com.br",
          role: UserRole.WAREHOUSE,
        },
        {
          name: "Saul Ramirez",
          email: "saul.ramirez@aerisservice.com",
          role: UserRole.WAREHOUSE,
        },
        
        // Field staff
        {
          name: "Jordy Perez",
          email: "jordy.perez@aerisservice.com",
          role: UserRole.FIELD,
        },
        {
          name: "Victor Vidal",
          email: "victor.vidal@aerisservice.com",
          role: UserRole.FIELD,
        },
        {
          name: "Jesus Garcia",
          email: "jesus.garcia@aerisservice.com", 
          role: UserRole.FIELD,
        },
        
        // Operational managers
        {
          name: "Ricardo Arellano",
          email: "ricardo.arellano@aerisservice.com",
          role: UserRole.OPERATIONAL,
        },
        {
          name: "Alejandro Villa",
          email: "alejandro.villa@aerisservice.com",
          role: UserRole.OPERATIONAL,
        },
        {
          name: "Alejandro Ruiz",
          email: "alejandro.ruiz@aerisservice.com",
          role: UserRole.OPERATIONAL,
        },
        {
          name: "Ramon Valencia",
          email: "ramon.valencia@aerisservice.com",
          role: UserRole.OPERATIONAL,
        },
        {
          name: "Martin Rosales",
          email: "martin.rosales@aerisservice.com",
          role: UserRole.OPERATIONAL,
        },
        {
          name: "Waldemar Guerra",
          email: "waldemar.guerra@aerisservice.com",
          role: UserRole.OPERATIONAL,
        },
        {
          name: "Rafael Duarte",
          email: "rafael.duarte@aerisservice.com",
          role: UserRole.OPERATIONAL,
        },
        
        // Director
        {
          name: "Evandro Prado",
          email: "evandro.prado@aerisservice.com",
          role: UserRole.DIRECTOR,
        },
      ];
      
      // Clear existing users first
      const existingUsers = await storage.getUsers();
      if (existingUsers.length > 0) {
        console.log("Clearing existing users before seeding new ones");
        // We can't actually clear users with the current interface,
        // but this would be the place to do it if we had that capability
      }
      
      // Create users with email as username and custom permissions
      for (const profile of userProfiles) {
        const email = profile.email;
        const existingUser = await storage.getUserByUsername(email);
        
        if (!existingUser) {
          // Create the user with email as username and custom permissions
          await storage.createUser({
            username: email,
            password: await hashPassword("password"),
            name: profile.name,
            email: email,
            role: profile.role,
            permissions: createCustomPermissions(email)
          });
          console.log(`Created user: ${profile.name} (${email})`);
        }
      }
      
      res.json({ message: "User seed completed successfully" });
    } catch (error) {
      console.error("Error seeding users:", error);
      res.status(500).json({ message: "Error seeding users" });
    }
  });
}
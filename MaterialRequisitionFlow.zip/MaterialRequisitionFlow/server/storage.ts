import { 
  User, InsertUser, 
  Project, InsertProject, 
  Requisition, InsertRequisition,
  RequisitionStatus, Priority,
  UpdateRequisitionStatus,
  UserRole, UserPermissions
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // Session store for authentication
  sessionStore: session.Store;
  
  // Usuários
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUsers(): Promise<User[]>;
  
  // Projetos
  getProject(id: number): Promise<Project | undefined>;
  getProjects(): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  
  // Requisições
  getRequisition(id: number): Promise<Requisition | undefined>;
  getRequisitionByNumber(requisitionNumber: string): Promise<Requisition | undefined>;
  createRequisition(requisition: InsertRequisition): Promise<Requisition>;
  updateRequisitionStatus(id: number, userId: number, update: UpdateRequisitionStatus): Promise<Requisition>;
  getRequisitions(): Promise<Requisition[]>;
  getRequisitionsByRequesterId(requesterId: number): Promise<Requisition[]>;
  getRequisitionsByStatus(status: RequisitionStatus): Promise<Requisition[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private projects: Map<number, Project>;
  private requisitions: Map<number, Requisition>;
  private userCurrentId: number;
  private projectCurrentId: number;
  private requisitionCurrentId: number;
  private requisitionNumberCounter: number;
  public sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.requisitions = new Map();
    this.userCurrentId = 1;
    this.projectCurrentId = 1;
    this.requisitionCurrentId = 1;
    this.requisitionNumberCounter = 1;
    
    // Initialize the session store
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // Prune expired entries every 24h
    });
    
    // Adicionar dados iniciais para demonstração
    this.seedInitialData();
  }

  private createPermissionsForRole(role: UserRole): UserPermissions {
    switch (role) {
      case UserRole.ADMIN:
        return {
          canCreateRequisition: true,
          canViewMyRequisitions: true,
          canApproveOperational: true,
          canApproveWarehouse: true,
          canApproveDirector: true,
          canPrepareMaterials: true,
          canShipMaterials: true,
          canViewHistory: true,
          canViewDashboard: true,
        };
      case UserRole.OPERATIONAL:
        return {
          canCreateRequisition: true,
          canViewMyRequisitions: true,
          canApproveOperational: true,
          canApproveWarehouse: false,
          canApproveDirector: false,
          canPrepareMaterials: false,
          canShipMaterials: false,
          canViewHistory: true,
          canViewDashboard: true,
        };
      case UserRole.WAREHOUSE:
        return {
          canCreateRequisition: true,
          canViewMyRequisitions: true,
          canApproveOperational: false,
          canApproveWarehouse: true,
          canApproveDirector: false,
          canPrepareMaterials: true,
          canShipMaterials: true,
          canViewHistory: true,
          canViewDashboard: true,
        };
      case UserRole.DIRECTOR:
        return {
          canCreateRequisition: true,
          canViewMyRequisitions: true,
          canApproveOperational: false,
          canApproveWarehouse: false,
          canApproveDirector: true,
          canPrepareMaterials: false,
          canShipMaterials: false,
          canViewHistory: true,
          canViewDashboard: true,
        };
      case UserRole.FIELD:
      default:
        return {
          canCreateRequisition: true,
          canViewMyRequisitions: true,
          canApproveOperational: false,
          canApproveWarehouse: false,
          canApproveDirector: false,
          canPrepareMaterials: false,
          canShipMaterials: false,
          canViewHistory: false,
          canViewDashboard: true,
        };
    }
  }

  private seedInitialData() {
    // Initial users
    // We'll skip seeding users here as we'll use the /api/seed-users endpoint instead
    
    // Initial projects
    const projects: InsertProject[] = [
      { code: "PROJ001", name: "Wind Turbine Maintenance - North" },
      { code: "PROJ002", name: "Structural Repair - Southeast" },
      { code: "PROJ003", name: "Equipment Installation - South" },
      { code: "PROJ004", name: "Gearbox Replacement - Midwest" },
      { code: "PROJ005", name: "Blade Repair - West" }
    ];
    
    projects.forEach(project => this.createProject(project));
  }

  // Implementação de Usuários
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    // First try exact username match
    const byUsername = Array.from(this.users.values()).find(
      (user) => user.username === username
    );
    
    if (byUsername) return byUsername;
    
    // If not found, try to find by email (since we're transitioning to use email as username)
    return Array.from(this.users.values()).find(
      (user) => user.email === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    // Ensure role is set with default
    const role = insertUser.role || UserRole.FIELD;
    
    // If permissions not provided, create them based on role
    const permissions = insertUser.permissions || this.createPermissionsForRole(role as UserRole);
    
    const user: User = { 
      ...insertUser, 
      id,
      role,
      permissions
    };
    
    this.users.set(id, user);
    return user;
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Implementação de Projetos
  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = this.projectCurrentId++;
    const project: Project = { ...insertProject, id };
    this.projects.set(id, project);
    return project;
  }

  // Implementação de Requisições
  async getRequisition(id: number): Promise<Requisition | undefined> {
    return this.requisitions.get(id);
  }

  async getRequisitionByNumber(requisitionNumber: string): Promise<Requisition | undefined> {
    return Array.from(this.requisitions.values()).find(
      (req) => req.requisitionNumber === requisitionNumber,
    );
  }

  async createRequisition(insertRequisition: InsertRequisition): Promise<Requisition> {
    const id = this.requisitionCurrentId++;
    const year = new Date().getFullYear();
    const requisitionNumber = `REQ-${year}-${this.requisitionNumberCounter.toString().padStart(3, '0')}`;
    this.requisitionNumberCounter++;
    
    const createdAt = new Date();
    
    const requisition: Requisition = { 
      ...insertRequisition, 
      id, 
      requisitionNumber,
      createdAt,
      status: insertRequisition.status || "PENDING_OPERATIONAL",
      number: insertRequisition.number || null,
      neighborhood: insertRequisition.neighborhood || null,
      complement: insertRequisition.complement || null,
      reference: insertRequisition.reference || null,
      operationalApproval: null,
      warehouseApproval: null,
      directorApproval: null,
      preparationInfo: null,
      shippingInfo: null,
      deliveryInfo: null
    };
    
    this.requisitions.set(id, requisition);
    return requisition;
  }

  async updateRequisitionStatus(id: number, userId: number, update: UpdateRequisitionStatus): Promise<Requisition> {
    const requisition = await this.getRequisition(id);
    
    if (!requisition) {
      throw new Error("Requisition not found");
    }
    
    const timestamp = new Date();
    const updateData = {
      userId,
      timestamp,
      notes: update.notes || ""
    };
    
    let updatedRequisition = { ...requisition, status: update.status };
    
    // Update the appropriate field based on status
    switch (update.status) {
      case RequisitionStatus.APPROVED:
      case RequisitionStatus.REJECTED:
      case RequisitionStatus.PENDING_WAREHOUSE:
      case RequisitionStatus.PENDING_DIRECTOR:
        // If previous status was PENDING_OPERATIONAL, then it's an operational approval
        if (requisition.status === RequisitionStatus.PENDING_OPERATIONAL) {
          updatedRequisition.operationalApproval = updateData;
        }
        // If previous status was PENDING_WAREHOUSE, then it's a warehouse approval
        else if (requisition.status === RequisitionStatus.PENDING_WAREHOUSE) {
          updatedRequisition.warehouseApproval = updateData;
        }
        // If previous status was PENDING_DIRECTOR, then it's a director approval
        else if (requisition.status === RequisitionStatus.PENDING_DIRECTOR) {
          updatedRequisition.directorApproval = updateData;
        }
        break;
      
      case RequisitionStatus.IN_PREPARATION:
        updatedRequisition.preparationInfo = updateData;
        break;
      
      case RequisitionStatus.SHIPPED:
        updatedRequisition.shippingInfo = {
          ...updateData,
          trackingCode: update.trackingCode || ""
        };
        break;
      
      case RequisitionStatus.DELIVERED:
        updatedRequisition.deliveryInfo = updateData;
        break;
    }
    
    this.requisitions.set(id, updatedRequisition);
    return updatedRequisition;
  }

  async getRequisitions(): Promise<Requisition[]> {
    return Array.from(this.requisitions.values());
  }

  async getRequisitionsByRequesterId(requesterId: number): Promise<Requisition[]> {
    return Array.from(this.requisitions.values()).filter(
      (req) => req.requesterId === requesterId,
    );
  }

  async getRequisitionsByStatus(status: RequisitionStatus): Promise<Requisition[]> {
    return Array.from(this.requisitions.values()).filter(
      (req) => req.status === status,
    );
  }
}

export const storage = new MemStorage();

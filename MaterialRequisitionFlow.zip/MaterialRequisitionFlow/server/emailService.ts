import nodemailer from 'nodemailer';
import { Requisition } from '@shared/schema';

// Create a test transporter for development (doesn't actually send emails)
// In a production environment, you would use an actual SMTP service
const transporter = nodemailer.createTransport({
  host: 'smtp.ethereal.email',
  port: 587,
  secure: false, // true for 465, false for other ports
  auth: {
    user: 'ethereal.user@ethereal.email', // generated ethereal user
    pass: 'ethereal_pass', // generated ethereal password
  },
});

// Define email recipients for each approval stage
const EMAIL_RECIPIENTS = {
  OPERATIONAL_APPROVAL: 'ricardo.arellano@aerisservice.com',
  WAREHOUSE_APPROVAL: 'eduardo.neto@aerisservices.com',
  DIRECTOR_APPROVAL: 'evandro.prado@aerisservice.com'
};

// Email templates
export async function sendOperationalApprovalEmail(requisition: Requisition): Promise<void> {
  try {
    const mailOptions = {
      from: '"Material Requisition System" <noreply@aerisservice.com>',
      to: EMAIL_RECIPIENTS.OPERATIONAL_APPROVAL,
      subject: `New Material Requisition #${requisition.requisitionNumber} Requires Approval`,
      html: `
        <h2>New Material Requisition Requires Approval</h2>
        <p>Requisition #${requisition.requisitionNumber} requires your approval.</p>
        <p><strong>Title:</strong> ${requisition.title}</p>
        <p><strong>Project:</strong> ${requisition.projectId}</p>
        <p><strong>Priority:</strong> ${requisition.priority}</p>
        <p>Please log in to the system to review and approve this requisition.</p>
      `
    };

    // Send the email (disabled in development)
    console.log('Sending operational approval email to:', EMAIL_RECIPIENTS.OPERATIONAL_APPROVAL);
    console.log('Email content:', mailOptions);
    
    // In production, uncomment the line below:
    // await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Error sending operational approval email:', error);
  }
}

export async function sendWarehouseApprovalEmail(requisition: Requisition): Promise<void> {
  try {
    const mailOptions = {
      from: '"Material Requisition System" <noreply@aerisservice.com>',
      to: EMAIL_RECIPIENTS.WAREHOUSE_APPROVAL,
      subject: `Material Requisition #${requisition.requisitionNumber} Requires Warehouse Approval`,
      html: `
        <h2>Material Requisition Requires Warehouse Approval</h2>
        <p>Requisition #${requisition.requisitionNumber} has been approved by Operations and requires your warehouse approval.</p>
        <p><strong>Title:</strong> ${requisition.title}</p>
        <p><strong>Project:</strong> ${requisition.projectId}</p>
        <p><strong>Priority:</strong> ${requisition.priority}</p>
        <p>Please log in to the system to review and approve this requisition.</p>
      `
    };

    // Send the email (disabled in development)
    console.log('Sending warehouse approval email to:', EMAIL_RECIPIENTS.WAREHOUSE_APPROVAL);
    console.log('Email content:', mailOptions);
    
    // In production, uncomment the line below:
    // await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Error sending warehouse approval email:', error);
  }
}

export async function sendDirectorApprovalEmail(requisition: Requisition): Promise<void> {
  try {
    const mailOptions = {
      from: '"Material Requisition System" <noreply@aerisservice.com>',
      to: EMAIL_RECIPIENTS.DIRECTOR_APPROVAL,
      subject: `Material Requisition #${requisition.requisitionNumber} Requires Director Approval`,
      html: `
        <h2>Material Requisition Requires Director Approval</h2>
        <p>Requisition #${requisition.requisitionNumber} has been approved by the Warehouse and requires your director approval.</p>
        <p><strong>Title:</strong> ${requisition.title}</p>
        <p><strong>Project:</strong> ${requisition.projectId}</p>
        <p><strong>Priority:</strong> ${requisition.priority}</p>
        <p>Please log in to the system to review and approve this requisition.</p>
      `
    };

    // Send the email (disabled in development)
    console.log('Sending director approval email to:', EMAIL_RECIPIENTS.DIRECTOR_APPROVAL);
    console.log('Email content:', mailOptions);
    
    // In production, uncomment the line below:
    // await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Error sending director approval email:', error);
  }
}
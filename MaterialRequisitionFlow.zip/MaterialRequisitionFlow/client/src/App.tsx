import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import Layout from "@/components/Layout";
import Home from "@/pages/Home";
import NovaRequisicao from "@/pages/NovaRequisicao"; // New Requisition
import MinhasRequisicoes from "@/pages/MinhasRequisicoes"; // My Requisitions
import Aprovacoes from "@/pages/Aprovacoes"; // Approvals
import Preparacao from "@/pages/Preparacao"; // Preparation
import Enviado from "@/pages/Enviado"; // Shipped
import Historico from "@/pages/Historico"; // History
import { RequisitionProvider } from "./components/RequisitionContext";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";

function Router() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={Home} />
      <ProtectedRoute path="/nova-requisicao" component={NovaRequisicao} />
      <ProtectedRoute path="/minhas-requisicoes" component={MinhasRequisicoes} />
      <ProtectedRoute path="/aprovacoes" component={Aprovacoes} />
      <ProtectedRoute path="/preparacao" component={Preparacao} />
      <ProtectedRoute path="/enviado" component={Enviado} />
      <ProtectedRoute path="/historico" component={Historico} />
      <Route path="/auth" component={AuthPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <RequisitionProvider>
          <Layout>
            <Router />
          </Layout>
          <Toaster />
        </RequisitionProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;

// Tipos adicionais para o aplicativo
import { Requisition } from "@shared/schema";

export interface RequisitionContextType {
  selectedRequisition: Requisition | null;
  setSelectedRequisition: (requisition: Requisition | null) => void;
}

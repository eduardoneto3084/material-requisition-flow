import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import RequisitionList from "@/components/RequisitionList";
import { Requisition, RequisitionStatus } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Aprovacoes() {
  // Fetch requisitions awaiting operational approval
  const { data: pendingOperational, isLoading: isLoadingOperational } = useQuery<Requisition[]>({
    queryKey: ['/api/requisitions', { status: RequisitionStatus.PENDING_OPERATIONAL }],
  });

  // Fetch requisitions awaiting warehouse approval
  const { data: pendingWarehouse, isLoading: isLoadingWarehouse } = useQuery<Requisition[]>({
    queryKey: ['/api/requisitions', { status: RequisitionStatus.PENDING_WAREHOUSE }],
  });

  // Fetch requisitions awaiting director approval
  const { data: pendingDirector, isLoading: isLoadingDirector } = useQuery<Requisition[]>({
    queryKey: ['/api/requisitions', { status: RequisitionStatus.PENDING_DIRECTOR }],
  });

  return (
    <div className="container mx-auto py-6">
      <Card>
        <CardHeader>
          <CardTitle>Requisitions Awaiting Approval</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="operational">
            <TabsList className="mb-4">
              <TabsTrigger value="operational">
                Operational Approval
                {pendingOperational && pendingOperational.length > 0 && (
                  <span className="ml-2 bg-red-500 text-white text-xs rounded-full px-1.5 py-0.5">
                    {pendingOperational.length}
                  </span>
                )}
              </TabsTrigger>
              <TabsTrigger value="warehouse">
                Warehouse Approval
                {pendingWarehouse && pendingWarehouse.length > 0 && (
                  <span className="ml-2 bg-red-500 text-white text-xs rounded-full px-1.5 py-0.5">
                    {pendingWarehouse.length}
                  </span>
                )}
              </TabsTrigger>
              <TabsTrigger value="director">
                Director Approval
                {pendingDirector && pendingDirector.length > 0 && (
                  <span className="ml-2 bg-red-500 text-white text-xs rounded-full px-1.5 py-0.5">
                    {pendingDirector.length}
                  </span>
                )}
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="operational">
              {isLoadingOperational ? (
                <div className="space-y-4">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : (
                <RequisitionList 
                  requisitions={pendingOperational || []} 
                  emptyMessage="No requisitions awaiting operational approval."
                />
              )}
            </TabsContent>
            
            <TabsContent value="warehouse">
              {isLoadingWarehouse ? (
                <div className="space-y-4">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : (
                <RequisitionList 
                  requisitions={pendingWarehouse || []} 
                  emptyMessage="No requisitions awaiting warehouse approval."
                />
              )}
            </TabsContent>
            
            <TabsContent value="director">
              {isLoadingDirector ? (
                <div className="space-y-4">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : (
                <RequisitionList 
                  requisitions={pendingDirector || []} 
                  emptyMessage="No requisitions awaiting director approval."
                />
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}

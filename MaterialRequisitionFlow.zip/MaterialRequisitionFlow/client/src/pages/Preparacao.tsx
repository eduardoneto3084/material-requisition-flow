import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import RequisitionList from "@/components/RequisitionList";
import { Requisition, RequisitionStatus } from "@shared/schema";

export default function Preparacao() {
  // Fetch requisitions in preparation
  const { data: requisitions, isLoading } = useQuery<Requisition[]>({
    queryKey: ['/api/requisitions', { status: RequisitionStatus.IN_PREPARATION }],
  });

  return (
    <div className="container mx-auto py-6">
      <Card>
        <CardHeader>
          <CardTitle>Requisitions in Preparation</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          ) : (
            <RequisitionList 
              requisitions={requisitions || []} 
              emptyMessage="There are no requisitions in preparation at the moment."
            />
          )}
        </CardContent>
      </Card>
    </div>
  );
}

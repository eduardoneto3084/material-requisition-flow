import { Card, CardContent } from "@/components/ui/card";
import RequisitionForm from "@/components/RequisitionForm";

export default function NovaRequisicao() {
  return (
    <div className="container mx-auto py-6">
      <Card className="mb-6">
        <CardContent className="pt-6">
          <h1 className="text-2xl font-bold mb-6">New Material Requisition</h1>
          <RequisitionForm />
        </CardContent>
      </Card>
    </div>
  );
}

import { useEffect } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import RequisitionList from "@/components/RequisitionList";
import { Button } from "@/components/ui/button";
import { Requisition } from "@shared/schema";
import { ArrowRight, PlusCircle } from "lucide-react";

export default function Home() {
  const [location, navigate] = useLocation();

  // Buscar as últimas requisições
  const { data: requisitions, isLoading } = useQuery<Requisition[]>({
    queryKey: ['/api/requisitions'],
  });

  return (
    <div className="container mx-auto py-6 space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <Button onClick={() => navigate("/nova-requisicao")} className="bg-primary hover:bg-blue-700">
          <PlusCircle className="mr-2 h-4 w-4" />
          New Requisition
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatsCard
          title="Waiting Approval"
          value={requisitions?.filter(r => r.status === "PENDING_OPERATIONAL" || r.status === "PENDING_WAREHOUSE").length || 0}
          status="warning"
          loading={isLoading}
        />
        <StatsCard
          title="In Preparation"
          value={requisitions?.filter(r => r.status === "IN_PREPARATION").length || 0}
          status="info"
          loading={isLoading}
        />
        <StatsCard
          title="Shipped"
          value={requisitions?.filter(r => r.status === "SHIPPED").length || 0}
          status="primary"
          loading={isLoading}
        />
        <StatsCard
          title="Delivered"
          value={requisitions?.filter(r => r.status === "DELIVERED").length || 0}
          status="success"
          loading={isLoading}
        />
      </div>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Recent Requisitions</CardTitle>
            <Button 
              variant="link" 
              className="text-primary flex items-center"
              onClick={() => navigate("/minhas-requisicoes")}
            >
              View all
              <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          ) : (
            <RequisitionList requisitions={requisitions?.slice(0, 5) || []} />
          )}
        </CardContent>
      </Card>
    </div>
  );
}

interface StatsCardProps {
  title: string;
  value: number;
  status: "warning" | "info" | "primary" | "success";
  loading: boolean;
}

function StatsCard({ title, value, status, loading }: StatsCardProps) {
  const getStatusColor = () => {
    switch (status) {
      case "warning": return "text-orange-500";
      case "info": return "text-blue-500";
      case "primary": return "text-purple-500";
      case "success": return "text-green-500";
      default: return "text-gray-500";
    }
  };

  return (
    <Card>
      <CardContent className="py-4">
        <div className="flex flex-col items-center text-center">
          <p className="text-sm font-medium text-gray-500">{title}</p>
          {loading ? (
            <Skeleton className="h-12 w-12 rounded-full mt-2" />
          ) : (
            <p className={`text-3xl font-bold mt-1 ${getStatusColor()}`}>{value}</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

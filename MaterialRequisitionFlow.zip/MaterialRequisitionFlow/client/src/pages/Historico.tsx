import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import RequisitionList from "@/components/RequisitionList";
import { Requisition, RequisitionStatus } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Historico() {
  // Fetch all requisitions for history
  const { data: requisitions, isLoading } = useQuery<Requisition[]>({
    queryKey: ['/api/requisitions'],
  });

  // Filter by status
  const delivered = requisitions?.filter(r => r.status === RequisitionStatus.DELIVERED) || [];
  const rejected = requisitions?.filter(r => r.status === RequisitionStatus.REJECTED) || [];
  const all = requisitions || [];

  return (
    <div className="container mx-auto py-6">
      <Card>
        <CardHeader>
          <CardTitle>Requisition History</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all">
            <TabsList className="mb-4">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="delivered">Delivered</TabsTrigger>
              <TabsTrigger value="rejected">Rejected</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all">
              {isLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : (
                <RequisitionList 
                  requisitions={all} 
                  emptyMessage="There are no requisitions in the history."
                />
              )}
            </TabsContent>
            
            <TabsContent value="delivered">
              {isLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : (
                <RequisitionList 
                  requisitions={delivered} 
                  emptyMessage="There are no delivered requisitions in the history."
                />
              )}
            </TabsContent>
            
            <TabsContent value="rejected">
              {isLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : (
                <RequisitionList 
                  requisitions={rejected} 
                  emptyMessage="There are no rejected requisitions in the history."
                />
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}

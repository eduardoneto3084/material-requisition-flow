import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Eye } from "lucide-react";
import { Requisition } from "@shared/schema";
import StatusBadge from "./StatusBadge";
import { useState } from "react";
import RequisitionDetail from "./RequisitionDetail";
import { useRequisition } from "./RequisitionContext";

interface RequisitionListProps {
  requisitions: Requisition[];
  emptyMessage?: string;
}

export default function RequisitionList({ requisitions, emptyMessage = "No requisitions found." }: RequisitionListProps) {
  const { setSelectedRequisition } = useRequisition();
  
  const handleViewRequisition = (requisition: Requisition) => {
    setSelectedRequisition(requisition);
  };

  if (requisitions.length === 0) {
    return <p className="text-center text-gray-500 py-4">{emptyMessage}</p>;
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>ID</TableHead>
            <TableHead>Title</TableHead>
            <TableHead>Project</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {requisitions.map((requisition) => (
            <TableRow key={requisition.id} className="hover:bg-gray-50">
              <TableCell className="font-medium">{requisition.requisitionNumber}</TableCell>
              <TableCell>{requisition.title}</TableCell>
              <TableCell>{requisition.projectId}</TableCell>
              <TableCell>{new Date(requisition.createdAt).toLocaleDateString('en-US')}</TableCell>
              <TableCell>
                <StatusBadge status={requisition.status} />
              </TableCell>
              <TableCell>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => handleViewRequisition(requisition)}
                  className="text-primary hover:text-blue-800"
                >
                  <Eye className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

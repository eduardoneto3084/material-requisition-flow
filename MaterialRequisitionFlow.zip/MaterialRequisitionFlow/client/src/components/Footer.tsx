export default function Footer() {
  return (
    <footer className="bg-white py-4 border-t">
      <div className="container mx-auto px-4">
        <p className="text-center text-gray-500 text-sm">
          © {new Date().getFullYear()} Material Requisition System. All rights reserved.
        </p>
      </div>
    </footer>
  );
}

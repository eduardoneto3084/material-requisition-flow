import { createContext, useContext, useState, ReactNode } from "react";
import { RequisitionContextType } from "@/lib/types";
import { Requisition } from "@shared/schema";
import RequisitionDetail from "./RequisitionDetail";

const RequisitionContext = createContext<RequisitionContextType | undefined>(undefined);

export function useRequisition() {
  const context = useContext(RequisitionContext);
  if (!context) {
    throw new Error("useRequisition must be used within a RequisitionProvider");
  }
  return context;
}

export function RequisitionProvider({ children }: { children: ReactNode }) {
  const [selectedRequisition, setSelectedRequisition] = useState<Requisition | null>(null);

  return (
    <RequisitionContext.Provider value={{ selectedRequisition, setSelectedRequisition }}>
      {children}
      <RequisitionDetail />
    </RequisitionContext.Provider>
  );
}

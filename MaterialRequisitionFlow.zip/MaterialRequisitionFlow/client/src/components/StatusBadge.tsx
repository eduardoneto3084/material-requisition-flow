import { RequisitionStatus } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface StatusBadgeProps {
  status: string;
}

export default function StatusBadge({ status }: StatusBadgeProps) {
  const getStatusConfig = () => {
    switch (status) {
      case RequisitionStatus.PENDING_OPERATIONAL:
        return {
          label: "Awaiting operational approval",
          variant: "bg-yellow-100 text-status-pending"
        };
      case RequisitionStatus.PENDING_WAREHOUSE:
        return {
          label: "Awaiting warehouse approval",
          variant: "bg-yellow-100 text-status-pending"
        };
      case RequisitionStatus.PENDING_DIRECTOR:
        return {
          label: "Awaiting director approval",
          variant: "bg-yellow-100 text-status-pending"
        };
      case RequisitionStatus.APPROVED:
        return {
          label: "Approved",
          variant: "bg-green-100 text-status-approved"
        };
      case RequisitionStatus.IN_PREPARATION:
        return {
          label: "In preparation",
          variant: "bg-blue-100 text-status-preparing"
        };
      case RequisitionStatus.SHIPPED:
        return {
          label: "Shipped",
          variant: "bg-purple-100 text-status-shipped"
        };
      case RequisitionStatus.DELIVERED:
        return {
          label: "Delivered",
          variant: "bg-green-100 text-status-approved"
        };
      case RequisitionStatus.REJECTED:
        return {
          label: "Rejected",
          variant: "bg-red-100 text-error"
        };
      default:
        return {
          label: status,
          variant: "bg-gray-100 text-gray-800"
        };
    }
  };

  const { label, variant } = getStatusConfig();

  return (
    <span className={cn("px-2 inline-flex text-xs leading-5 font-semibold rounded-full", variant)}>
      {label}
    </span>
  );
}

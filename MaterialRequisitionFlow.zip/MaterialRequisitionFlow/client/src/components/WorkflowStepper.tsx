import { Requisition, RequisitionStatus, ApprovalInfo, ShippingInfo } from "@shared/schema";

interface WorkflowStepperProps {
  requisition: Requisition;
}

interface Step {
  label: string;
  status: "completed" | "current" | "upcoming";
  icon: string;
  date?: string;
}

export default function WorkflowStepper({ requisition }: WorkflowStepperProps) {
  // Define the status of each step
  const getStepStatus = (stepStatus: RequisitionStatus): "completed" | "current" | "upcoming" => {
    const statuses: Record<RequisitionStatus, number> = {
      [RequisitionStatus.PENDING_OPERATIONAL]: 0,
      [RequisitionStatus.PENDING_WAREHOUSE]: 1,
      [RequisitionStatus.PENDING_DIRECTOR]: 2,
      [RequisitionStatus.APPROVED]: 3,
      [RequisitionStatus.IN_PREPARATION]: 4,
      [RequisitionStatus.SHIPPED]: 5,
      [RequisitionStatus.DELIVERED]: 6,
      [RequisitionStatus.REJECTED]: -1,
    };

    const currentStepIndex = statuses[requisition.status as RequisitionStatus];
    const stepIndex = statuses[stepStatus];
    
    // If rejected, all future steps are "upcoming"
    if (currentStepIndex === -1 && stepIndex > 0) {
      return "upcoming";
    }
    
    if (stepIndex < currentStepIndex) {
      return "completed";
    } else if (stepIndex === currentStepIndex) {
      return "current";
    } else {
      return "upcoming";
    }
  };

  // Format dates
  const formatDate = (date: string | Date) => {
    if (!date) return "Pending";
    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // Determine the workflow steps
  const steps: Step[] = [
    {
      label: "Requested",
      status: "completed", // Always completed if the requisition exists
      icon: "check",
      date: formatDate(requisition.createdAt),
    },
    {
      label: "Operational Approval",
      status: getStepStatus(RequisitionStatus.PENDING_OPERATIONAL),
      icon: requisition.operationalApproval ? "check" : "pending",
      date: requisition.operationalApproval 
        ? formatDate((requisition.operationalApproval as ApprovalInfo).timestamp) 
        : "Pending",
    },
    {
      label: "Warehouse Approval",
      status: getStepStatus(RequisitionStatus.PENDING_WAREHOUSE),
      icon: requisition.warehouseApproval ? "check" : "pending",
      date: requisition.warehouseApproval 
        ? formatDate((requisition.warehouseApproval as ApprovalInfo).timestamp) 
        : "Pending",
    },
    {
      label: "Director Approval",
      status: getStepStatus(RequisitionStatus.PENDING_DIRECTOR),
      icon: requisition.directorApproval ? "check" : "pending",
      date: requisition.directorApproval 
        ? formatDate((requisition.directorApproval as ApprovalInfo).timestamp) 
        : "Pending",
    },
    {
      label: "Preparation",
      status: getStepStatus(RequisitionStatus.IN_PREPARATION),
      icon: "inventory",
      date: requisition.preparationInfo 
        ? formatDate((requisition.preparationInfo as ApprovalInfo).timestamp) 
        : "Pending",
    },
    {
      label: "Shipping",
      status: getStepStatus(RequisitionStatus.SHIPPED),
      icon: "local_shipping",
      date: requisition.shippingInfo 
        ? formatDate((requisition.shippingInfo as ShippingInfo).timestamp) 
        : "Pending",
    },
    {
      label: "Delivered",
      status: getStepStatus(RequisitionStatus.DELIVERED),
      icon: "task_alt",
      date: requisition.deliveryInfo 
        ? formatDate((requisition.deliveryInfo as ApprovalInfo).timestamp) 
        : "Pending",
    },
  ];

  // Render the status symbol for each step
  const getStepIcon = (step: Step) => {
    let bgColor = "bg-gray-300";
    
    if (step.status === "completed") {
      bgColor = "bg-green-500";
    } else if (step.status === "current") {
      if (requisition.status === RequisitionStatus.PENDING_OPERATIONAL || 
          requisition.status === RequisitionStatus.PENDING_WAREHOUSE ||
          requisition.status === RequisitionStatus.PENDING_DIRECTOR) {
        bgColor = "bg-status-pending";
      } else if (requisition.status === RequisitionStatus.IN_PREPARATION) {
        bgColor = "bg-status-preparing";
      } else if (requisition.status === RequisitionStatus.SHIPPED) {
        bgColor = "bg-status-shipped";
      } else if (requisition.status === RequisitionStatus.DELIVERED) {
        bgColor = "bg-status-approved";
      } else if (requisition.status === RequisitionStatus.REJECTED) {
        bgColor = "bg-error";
      }
    }
    
    return (
      <div className={`rounded-full h-12 w-12 flex items-center justify-center ${bgColor} text-white`}>
        <span className="material-icons">{step.icon}</span>
      </div>
    );
  };

  // Render the connection line between steps
  const getConnectorLine = (index: number, stepsCount: number) => {
    if (index === stepsCount - 1) return null;
    
    const currentStep = steps[index];
    const nextStep = steps[index + 1];
    
    let borderColor = "border-gray-300";
    
    if (currentStep.status === "completed" && nextStep.status !== "upcoming") {
      borderColor = "border-green-500";
    }
    
    return <div className={`flex-auto border-t-2 ${borderColor}`} />;
  };

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between">
        {steps.map((step, index) => (
          <div key={index} className="flex flex-col items-center relative">
            {getStepIcon(step)}
            <div className="text-xs mt-1">{step.label}</div>
            <div className="absolute top-6 text-xs text-gray-500 w-32 text-center mt-8">
              {step.date}
            </div>
            {getConnectorLine(index, steps.length)}
          </div>
        ))}
      </div>
    </div>
  );
}

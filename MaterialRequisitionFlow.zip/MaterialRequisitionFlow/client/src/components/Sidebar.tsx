import { useLocation } from "wouter";
import { Fragment } from "react";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";

interface SidebarProps {
  open: boolean;
  setOpen: (open: boolean) => void;
}

interface SidebarItem {
  name: string;
  path: string;
  icon: string;
  badge?: number;
  permissionCheck: (permissions: any) => boolean;
}

export default function Sidebar({ open, setOpen }: SidebarProps) {
  const [location] = useLocation();
  const { user, isLoading } = useAuth();

  const sidebarItems: SidebarItem[] = [
    { 
      name: "Dashboard", 
      path: "/", 
      icon: "dashboard",
      permissionCheck: (permissions) => permissions?.canViewDashboard || false
    },
    { 
      name: "New Requisition", 
      path: "/nova-requisicao", 
      icon: "add_circle",
      permissionCheck: (permissions) => permissions?.canCreateRequisition || false
    },
    { 
      name: "My Requisitions", 
      path: "/minhas-requisicoes", 
      icon: "list_alt",
      permissionCheck: (permissions) => permissions?.canViewMyRequisitions || false
    },
    { 
      name: "Operational Approval", 
      path: "/aprovacoes", 
      icon: "approval", 
      badge: 2,
      permissionCheck: (permissions) => permissions?.canApproveOperational || false
    },
    { 
      name: "Warehouse Approval", 
      path: "/aprovacoes", 
      icon: "approval",
      permissionCheck: (permissions) => permissions?.canApproveWarehouse || false
    },
    { 
      name: "Director Approval", 
      path: "/aprovacoes", 
      icon: "approval",
      permissionCheck: (permissions) => permissions?.canApproveDirector || false
    },
    { 
      name: "In Preparation", 
      path: "/preparacao", 
      icon: "inventory_2",
      permissionCheck: (permissions) => permissions?.canPrepareMaterials || false
    },
    { 
      name: "Shipped", 
      path: "/enviado", 
      icon: "local_shipping",
      permissionCheck: (permissions) => permissions?.canShipMaterials || false
    },
    { 
      name: "History", 
      path: "/historico", 
      icon: "schedule",
      permissionCheck: (permissions) => permissions?.canViewHistory || false
    },
  ];

  const closeSidebar = () => {
    setOpen(false);
  };

  // Filter sidebar items based on user permissions
  const filteredItems = sidebarItems.filter(item => {
    if (!user || !user.permissions) return false;
    return item.permissionCheck(user.permissions);
  });

  return (
    <>
      {/* Overlay for mobile */}
      {open && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden" 
          onClick={closeSidebar}
        />
      )}
      
      {/* Sidebar */}
      <aside 
        className={cn(
          "w-64 bg-white shadow-md fixed inset-y-0 left-0 z-50 transform transition-transform duration-300 ease-in-out md:translate-x-0 md:relative md:z-0",
          open ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex justify-end p-2 md:hidden">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={closeSidebar} 
            className="text-gray-500"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <nav className="py-4">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-32">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
              <p className="mt-2 text-sm text-muted-foreground">Loading menu...</p>
            </div>
          ) : (
            <ul>
              {filteredItems.map((item) => (
                <li key={item.path + item.name}>
                  <a
                    href={item.path}
                    className={cn(
                      "flex items-center px-6 py-3",
                      location === item.path 
                        ? "text-primary border-l-4 border-primary bg-blue-50" 
                        : "text-gray-700 hover:bg-gray-100"
                    )}
                    onClick={(e) => {
                      if (window.innerWidth < 768) {
                        closeSidebar();
                      }
                    }}
                  >
                    <span className="material-icons mr-3">{item.icon}</span>
                    <span>{item.name}</span>
                    {item.badge && (
                      <span className="ml-auto bg-red-500 text-white text-xs rounded-full px-1.5">
                        {item.badge}
                      </span>
                    )}
                  </a>
                </li>
              ))}
            </ul>
          )}
        </nav>
      </aside>
    </>
  );
}

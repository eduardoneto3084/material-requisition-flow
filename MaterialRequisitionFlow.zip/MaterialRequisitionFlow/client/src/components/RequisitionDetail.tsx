import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import WorkflowStepper from "./WorkflowStepper";
import { Requisition, RequisitionStatus, UpdateRequisitionStatus, ShippingInfo, ApprovalInfo } from "@shared/schema";
import { Check, Download, Eye, Package, Truck, X } from "lucide-react";
import { useRequisition } from "./RequisitionContext";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Schema para formulário de atualização de status com código de rastreio
const shippingFormSchema = z.object({
  trackingCode: z.string().min(1, "Código de rastreio é obrigatório"),
  notes: z.string().optional(),
});

// Schema para formulário de notas
const notesFormSchema = z.object({
  notes: z.string().optional(),
});

export default function RequisitionDetail() {
  const { selectedRequisition, setSelectedRequisition } = useRequisition();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Formulário para envio (com código de rastreio)
  const shippingForm = useForm<z.infer<typeof shippingFormSchema>>({
    resolver: zodResolver(shippingFormSchema),
    defaultValues: {
      trackingCode: "",
      notes: "",
    },
  });
  
  // Formulário para outras atualizações
  const notesForm = useForm<z.infer<typeof notesFormSchema>>({
    resolver: zodResolver(notesFormSchema),
    defaultValues: {
      notes: "",
    },
  });
  
  // Função para atualizar o status da requisição
  const updateStatus = useMutation({
    mutationFn: async (data: UpdateRequisitionStatus) => {
      if (!selectedRequisition) return null;
      return apiRequest("PATCH", `/api/requisitions/${selectedRequisition.id}/status`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/requisitions'] });
      toast({
        title: "Status atualizado",
        description: "O status da requisição foi atualizado com sucesso.",
        variant: "success",
      });
      setSelectedRequisition(null);
    },
    onError: (error) => {
      toast({
        title: "Erro ao atualizar status",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleUpdateStatus = (status: RequisitionStatus) => {
    if (status === RequisitionStatus.SHIPPED) {
      // Para envio, precisamos do código de rastreio
      shippingForm.handleSubmit((data) => {
        updateStatus.mutate({
          status,
          notes: data.notes,
          trackingCode: data.trackingCode,
        });
      })();
    } else {
      // Para outros status, só precisamos das notas opcionais
      notesForm.handleSubmit((data) => {
        updateStatus.mutate({
          status,
          notes: data.notes,
        });
      })();
    }
  };
  
  // Renderizar ações disponíveis com base no status atual
  const renderActions = () => {
    if (!selectedRequisition) return null;
    
    const status = selectedRequisition.status;
    
    if (status === RequisitionStatus.PENDING_OPERATIONAL) {
      return (
        <div className="bg-yellow-50 border border-yellow-100 rounded-md p-4 mb-6">
          <h4 className="text-status-pending font-medium flex items-center mb-3">
            <span className="material-icons mr-1">pending</span>
            Awaiting Operational Approval
          </h4>
          <p className="text-sm text-gray-700 mb-4">
            This requisition is awaiting approval from the operational manager.
          </p>
          
          <Form {...notesForm}>
            <form className="space-y-4">
              <FormField
                control={notesForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes (optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Notes about approval or rejection"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex space-x-4">
                <Button
                  type="button"
                  onClick={() => handleUpdateStatus(RequisitionStatus.PENDING_WAREHOUSE)}
                  className="bg-status-approved hover:bg-green-700"
                >
                  <Check className="h-4 w-4 mr-1" />
                  Approve
                </Button>
                <Button
                  type="button"
                  onClick={() => handleUpdateStatus(RequisitionStatus.REJECTED)}
                  className="bg-error hover:bg-red-700"
                >
                  <X className="h-4 w-4 mr-1" />
                  Reject
                </Button>
              </div>
            </form>
          </Form>
        </div>
      );
    } else if (status === RequisitionStatus.PENDING_WAREHOUSE) {
      return (
        <div className="bg-yellow-50 border border-yellow-100 rounded-md p-4 mb-6">
          <h4 className="text-status-pending font-medium flex items-center mb-3">
            <span className="material-icons mr-1">pending</span>
            Awaiting Warehouse Approval
          </h4>
          <p className="text-sm text-gray-700 mb-4">
            This requisition is awaiting approval from the warehouse manager.
          </p>
          
          <Form {...notesForm}>
            <form className="space-y-4">
              <FormField
                control={notesForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes (optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Notes about approval or rejection"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex space-x-4">
                <Button
                  type="button"
                  onClick={() => handleUpdateStatus(RequisitionStatus.PENDING_DIRECTOR)}
                  className="bg-status-approved hover:bg-green-700"
                >
                  <Check className="h-4 w-4 mr-1" />
                  Approve
                </Button>
                <Button
                  type="button"
                  onClick={() => handleUpdateStatus(RequisitionStatus.REJECTED)}
                  className="bg-error hover:bg-red-700"
                >
                  <X className="h-4 w-4 mr-1" />
                  Reject
                </Button>
              </div>
            </form>
          </Form>
        </div>
      );
    } else if (status === RequisitionStatus.PENDING_DIRECTOR) {
      return (
        <div className="bg-yellow-50 border border-yellow-100 rounded-md p-4 mb-6">
          <h4 className="text-status-pending font-medium flex items-center mb-3">
            <span className="material-icons mr-1">pending</span>
            Awaiting Director Approval
          </h4>
          <p className="text-sm text-gray-700 mb-4">
            This requisition is awaiting approval from the director.
          </p>
          
          <Form {...notesForm}>
            <form className="space-y-4">
              <FormField
                control={notesForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes (optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Notes about approval or rejection"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex space-x-4">
                <Button
                  type="button"
                  onClick={() => handleUpdateStatus(RequisitionStatus.APPROVED)}
                  className="bg-status-approved hover:bg-green-700"
                >
                  <Check className="h-4 w-4 mr-1" />
                  Approve
                </Button>
                <Button
                  type="button"
                  onClick={() => handleUpdateStatus(RequisitionStatus.REJECTED)}
                  className="bg-error hover:bg-red-700"
                >
                  <X className="h-4 w-4 mr-1" />
                  Reject
                </Button>
              </div>
            </form>
          </Form>
        </div>
      );
    } else if (status === RequisitionStatus.APPROVED) {
      return (
        <div className="bg-blue-50 border border-blue-100 rounded-md p-4 mb-6">
          <h4 className="text-blue-600 font-medium flex items-center mb-3">
            <span className="material-icons mr-1">check_circle</span>
            Approved
          </h4>
          <p className="text-sm text-gray-700 mb-4">
            This requisition has been approved and is ready for preparation.
          </p>
          
          <Form {...notesForm}>
            <form className="space-y-4">
              <FormField
                control={notesForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes (optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Notes about preparation"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <Button
                type="button"
                onClick={() => handleUpdateStatus(RequisitionStatus.IN_PREPARATION)}
                className="bg-status-preparing hover:bg-blue-700"
              >
                <Package className="h-4 w-4 mr-1" />
                Start Preparation
              </Button>
            </form>
          </Form>
        </div>
      );
    } else if (status === RequisitionStatus.IN_PREPARATION) {
      return (
        <div className="bg-blue-50 border border-blue-100 rounded-md p-4 mb-6">
          <h4 className="text-status-preparing font-medium flex items-center mb-3">
            <span className="material-icons mr-1">inventory</span>
            Em Preparação
          </h4>
          <p className="text-sm text-gray-700 mb-4">
            Esta requisição está sendo preparada para envio.
          </p>
          
          <Form {...shippingForm}>
            <form className="space-y-4">
              <FormField
                control={shippingForm.control}
                name="trackingCode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Código de Rastreio *</FormLabel>
                    <FormControl>
                      <Input placeholder="Ex: BR123456789XX" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={shippingForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Observações (opcional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Observações sobre o envio"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <Button
                type="button"
                onClick={() => handleUpdateStatus(RequisitionStatus.SHIPPED)}
                className="bg-status-shipped hover:bg-purple-700"
              >
                <Truck className="h-4 w-4 mr-1" />
                Enviar
              </Button>
            </form>
          </Form>
        </div>
      );
    } else if (status === RequisitionStatus.SHIPPED) {
      return (
        <div className="bg-purple-50 border border-purple-100 rounded-md p-4 mb-6">
          <h4 className="text-status-shipped font-medium flex items-center mb-3">
            <span className="material-icons mr-1">local_shipping</span>
            Enviado
          </h4>
          <p className="text-sm text-gray-700 mb-4">
            Esta requisição foi enviada e está a caminho.
          </p>
          <p className="text-sm text-gray-700 mb-4">
            <strong>Código de Rastreio:</strong> {(selectedRequisition.shippingInfo as ShippingInfo)?.trackingCode}
          </p>
          
          <Form {...notesForm}>
            <form className="space-y-4">
              <FormField
                control={notesForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Observações (opcional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Observações sobre a entrega"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <Button
                type="button"
                onClick={() => handleUpdateStatus(RequisitionStatus.DELIVERED)}
                className="bg-status-approved hover:bg-green-700"
              >
                <Check className="h-4 w-4 mr-1" />
                Confirmar Entrega
              </Button>
            </form>
          </Form>
        </div>
      );
    } else if (status === RequisitionStatus.DELIVERED) {
      return (
        <div className="bg-green-50 border border-green-100 rounded-md p-4 mb-6">
          <h4 className="text-status-approved font-medium flex items-center mb-3">
            <span className="material-icons mr-1">task_alt</span>
            Entregue
          </h4>
          <p className="text-sm text-gray-700">
            Esta requisição foi entregue com sucesso.
          </p>
        </div>
      );
    } else if (status === RequisitionStatus.REJECTED) {
      return (
        <div className="bg-red-50 border border-red-100 rounded-md p-4 mb-6">
          <h4 className="text-error font-medium flex items-center mb-3">
            <span className="material-icons mr-1">cancel</span>
            Rejeitado
          </h4>
          <p className="text-sm text-gray-700">
            Esta requisição foi rejeitada.
          </p>
        </div>
      );
    }
    
    return null;
  };
  
  if (!selectedRequisition) return null;
  
  return (
    <Dialog open={!!selectedRequisition} onOpenChange={(open) => !open && setSelectedRequisition(null)}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Detalhes da Requisição: {selectedRequisition.requisitionNumber}</DialogTitle>
        </DialogHeader>
        
        <WorkflowStepper requisition={selectedRequisition} />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <h4 className="font-medium mb-3">Informações da Requisição</h4>
            <Card>
              <CardContent className="p-4">
                <div className="grid grid-cols-3 gap-4 mb-2">
                  <div className="text-sm font-medium text-gray-500">ID:</div>
                  <div className="col-span-2 text-sm text-gray-900">{selectedRequisition.requisitionNumber}</div>
                </div>
                <div className="grid grid-cols-3 gap-4 mb-2">
                  <div className="text-sm font-medium text-gray-500">Título:</div>
                  <div className="col-span-2 text-sm text-gray-900">{selectedRequisition.title}</div>
                </div>
                <div className="grid grid-cols-3 gap-4 mb-2">
                  <div className="text-sm font-medium text-gray-500">Projeto:</div>
                  <div className="col-span-2 text-sm text-gray-900">
                    Projeto ID: {selectedRequisition.projectId}
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4 mb-2">
                  <div className="text-sm font-medium text-gray-500">Solicitante:</div>
                  <div className="col-span-2 text-sm text-gray-900">
                    ID: {selectedRequisition.requesterId}
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4 mb-2">
                  <div className="text-sm font-medium text-gray-500">Data:</div>
                  <div className="col-span-2 text-sm text-gray-900">
                    {new Date(selectedRequisition.createdAt).toLocaleString('pt-BR')}
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4 mb-2">
                  <div className="text-sm font-medium text-gray-500">Priority:</div>
                  <div className="col-span-2">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      selectedRequisition.priority === 'OVERNIGHT' ? 'bg-red-100 text-red-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {selectedRequisition.priority === 'OVERNIGHT' ? 'Overnight' : 'Standard Shipping'}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div>
            <h4 className="font-medium mb-3">Delivery Address</h4>
            <Card>
              <CardContent className="p-4">
                <p className="text-sm text-gray-900 mb-1">{selectedRequisition.street}</p>
                {selectedRequisition.complement && (
                  <p className="text-sm text-gray-900 mb-1">{selectedRequisition.complement}</p>
                )}
                <p className="text-sm text-gray-900 mb-1">{selectedRequisition.city} - {selectedRequisition.state}</p>
                <p className="text-sm text-gray-900 mb-1">Zip Code: {selectedRequisition.zipCode}</p>
                {selectedRequisition.reference && (
                  <p className="text-sm text-gray-900">Reference: {selectedRequisition.reference}</p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
        
        <div className="mb-6">
          <h4 className="font-medium mb-3">Request Description</h4>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-gray-900">
                {selectedRequisition.description}
              </p>
            </CardContent>
          </Card>
        </div>
        
        <div className="mb-6">
          <h4 className="font-medium mb-3">Attached Document</h4>
          <Card>
            <CardContent className="p-4 flex items-center">
              <span className="material-icons text-red-600 mr-2">picture_as_pdf</span>
              <span className="text-sm font-medium">{selectedRequisition.pdfName}</span>
              <span className="text-xs text-gray-500 ml-2">
                {Math.round(selectedRequisition.pdfSize / 1024 / 1024 * 10) / 10} MB
              </span>
              <Button
                variant="ghost"
                size="sm"
                className="ml-auto text-primary hover:text-blue-800 text-sm flex items-center"
                asChild
              >
                <a href={`/api/uploads/${selectedRequisition.pdfPath.split('/').pop()}`} download target="_blank">
                  <Download className="h-4 w-4 mr-1" />
                  Download
                </a>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="ml-3 text-primary hover:text-blue-800 text-sm flex items-center"
                asChild
              >
                <a href={`/api/uploads/${selectedRequisition.pdfPath.split('/').pop()}`} target="_blank">
                  <Eye className="h-4 w-4 mr-1" />
                  View
                </a>
              </Button>
            </CardContent>
          </Card>
        </div>
        
        {/* Display actions specific to the current status */}
        {renderActions()}
        
        <DialogFooter>
          <Button variant="outline" onClick={() => setSelectedRequisition(null)}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

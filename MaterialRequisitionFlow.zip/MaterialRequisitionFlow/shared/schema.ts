import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Requisition status
export enum RequisitionStatus {
  PENDING_OPERATIONAL = "PENDING_OPERATIONAL", // Waiting for operational approval
  PENDING_WAREHOUSE = "PENDING_WAREHOUSE", // Waiting for warehouse approval
  PENDING_DIRECTOR = "PENDING_DIRECTOR", // Waiting for director approval
  APPROVED = "APPROVED", // Approved
  REJECTED = "REJECTED", // Rejected
  IN_PREPARATION = "IN_PREPARATION", // In preparation
  SHIPPED = "SHIPPED", // Shipped
  DELIVERED = "DELIVERED", // Delivered
}

// Requisition priority
export enum Priority {
  STANDARD = "STANDARD", // Standard Shipping
  OVERNIGHT = "OVERNIGHT", // Overnight
}

// User roles
export enum UserRole {
  ADMIN = "ADMIN", // Full access to everything
  OPERATIONAL = "OPERATIONAL", // Can approve operational
  WAREHOUSE = "WAREHOUSE", // Can approve warehouse
  DIRECTOR = "DIRECTOR", // Can approve as director
  FIELD = "FIELD", // Limited access
}

// User permissions
export interface UserPermissions {
  canCreateRequisition: boolean;
  canViewMyRequisitions: boolean;
  canApproveOperational: boolean;
  canApproveWarehouse: boolean;
  canApproveDirector: boolean;
  canPrepareMaterials: boolean;
  canShipMaterials: boolean;
  canViewHistory: boolean;
  canViewDashboard: boolean;
}

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  role: text("role").notNull().default("FIELD"),
  permissions: json("permissions").notNull().$type<UserPermissions>(),
});

// Projects table
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
});

// Requisitions table
export const requisitions = pgTable("requisitions", {
  id: serial("id").primaryKey(),
  requisitionNumber: text("requisition_number").notNull().unique(), // REQ-2023-001
  title: text("title").notNull(),
  description: text("description").notNull(),
  projectId: text("project_id").notNull(),
  priority: text("priority").notNull(), // STANDARD, OVERNIGHT
  requesterId: integer("requester_id").notNull(),
  status: text("status").notNull().default("PENDING_OPERATIONAL"),
  pdfPath: text("pdf_path").notNull(),
  pdfName: text("pdf_name").notNull(),
  pdfSize: integer("pdf_size").notNull(),
  street: text("street").notNull(),
  number: text("number"),
  complement: text("complement"),
  neighborhood: text("neighborhood"),
  city: text("city").notNull(),
  state: text("state").notNull(),
  zipCode: text("zip_code").notNull(),
  reference: text("reference"),
  signature: text("signature").notNull(), // Base64 signature
  createdAt: timestamp("created_at").notNull().defaultNow(),
  operationalApproval: json("operational_approval"),  // { userId, timestamp, notes }
  warehouseApproval: json("warehouse_approval"),      // { userId, timestamp, notes }
  directorApproval: json("director_approval"),       // { userId, timestamp, notes }
  preparationInfo: json("preparation_info"),         // { userId, timestamp, notes }
  shippingInfo: json("shipping_info"),               // { userId, timestamp, notes, trackingCode }
  deliveryInfo: json("delivery_info"),               // { userId, timestamp, notes }
});

// User insertion schema
export const insertUserSchema = createInsertSchema(users);
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Project insertion schema
export const insertProjectSchema = createInsertSchema(projects);
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

// Requisition insertion schema
export const insertRequisitionSchema = createInsertSchema(requisitions).omit({
  requisitionNumber: true,
  createdAt: true,
  operationalApproval: true,
  warehouseApproval: true,
  directorApproval: true,
  preparationInfo: true,
  shippingInfo: true,
  deliveryInfo: true,
});

// Form validation schema for requisition
export const requisitionFormSchema = insertRequisitionSchema.extend({
  pdf: z.instanceof(File, { message: "PDF file is required" }),
});

// Types for requisition
export type InsertRequisition = z.infer<typeof insertRequisitionSchema>;
export type Requisition = typeof requisitions.$inferSelect;

// Schema for updating requisition status
export const updateRequisitionStatusSchema = z.object({
  status: z.nativeEnum(RequisitionStatus),
  notes: z.string().optional(),
  trackingCode: z.string().optional(), // Only used when status is SHIPPED
});

export type UpdateRequisitionStatus = z.infer<typeof updateRequisitionStatusSchema>;

// Type for approval information
export interface ApprovalInfo {
  userId: number;
  timestamp: Date;
  notes: string;
}

// Type for shipping information
export interface ShippingInfo extends ApprovalInfo {
  trackingCode: string;
}
